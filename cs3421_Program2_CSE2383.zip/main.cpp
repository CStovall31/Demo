#include <iostream>
#include <string>

/*

Student Name: Courtney Stovall
Student NetID: cs3421
Compiler/IDE Used: Visual Studio
Program Discription:

This program makes two queues one for the worker name
and one for the worker daily salary. Once the worker
information is Enqueued by pressing  number 1. 
There's another option in the menu to Dequeue the 
que by pressing number 2. 
*/

using namespace std;

class worker {

	struct node {

		string name;
		node *next;
	};

	struct node2 {

		float incomeTax;
		node2 *next2;
	};

	char choice;

	float incomeTax, pretax, tax, hoursWorked, hourlyRate;
	string name, fname, lname;

	node *head = NULL;
	node *tail = NULL;

	node2 *head2 = NULL;
	node2 *tail2 = NULL;

public:

	bool isEmpty(node *head) {

		if (head == NULL) {
			return true;
		}
		else {
			return false;
		}
	}

	bool isEmpty2(node2 *head2) {

		if (head2 == NULL) {
			return true;
		}
		else {
			return false;
		}
	}

	void firstInsert(node *&head, node *&tail, string name) {

		node *temp = new node;
		temp->name = name;
		temp->next = NULL;
		head = temp;
		tail = temp;
	}

	void firstInsert2(node2 *&head2, node2 *&tail2, float incomeTax) {

		node2 *temp2 = new node2;
		temp2->incomeTax = incomeTax;
		temp2->next2 = NULL;
		head2 = temp2;
		tail2 = temp2;
	}

	void insertName(node *&head, node *&tail, string name) {

		if (isEmpty(head)) {
			firstInsert(head, tail, name);
		}

		else {

			node *temp = new node;
			temp->name = name;
			temp->next = NULL;
			tail->next = temp;
			tail = temp;
		}
	}

	void removeName(node *&head, node *&tail) {

		if (isEmpty(head)) {
			cout << "";
		}

		else if (head == tail) {
			delete head;
			head = NULL;
			tail == NULL;
		}

		else {
			node *temp = head;
			head = head->next;
			delete temp;
		}
	}

	void insertNum(node2 *&head2, node2 *&tail2, float incomeTax) {

		if (isEmpty2(head2)) {
			firstInsert2(head2, tail2, incomeTax);
		}

		else {

			node2 *temp2 = new node2;
			temp2->incomeTax = incomeTax;
			temp2->next2 = NULL;
			tail2->next2 = temp2;
			tail2 = temp2;
		}
	}

	void removeNum(node2 *&head2, node2 *&tail2) {

		if (isEmpty2(head2)) {
			cout << "";
		}

		else if (head2 == tail2) {
			delete head2;
			head2 = NULL;
			tail2 == NULL;
		}

		else {

			node2 *temp2 = head2;
			head2 = head2->next2;
			delete temp2;
		}
	}

	void activeEmployees(node *current) {
		if (isEmpty(current)) {
			cout << "\nList of Active Employees:\n";
		}

		else {
			cout << "\nList of Active Employees:\n";

			while (current != NULL) {
				cout << "[" << current->name << "]" << " ";
				current = current->next;
			}
			cout << endl;
		}
	}

	void clock_out_name(node *current) {

		if (isEmpty(current)) {
			cout << "";
		}

		else {
			cout << "\nEmployee ready to leave\n";

			cout << "\nFull Name: " << current->name;
			current = current->next;
			cout << endl;
		}
	}

	void dailySalary(node2 *current2) {

		if (isEmpty2(current2)) {
			cout << "";
		}

		else {
			cout << "Daily Salary: " << current2->incomeTax;
			cout << "\n-----------------------";
			current2 = current2->next2;
			cout << endl;
		}
	}

	void selectionMenu() {

		cout << "Welcome to the Popcorn Cafeteria!\n";

		do {

			activeEmployees(head);

			cout << "\nWhat would you like to do?\n";
			cout << "1. Enter an employee info\n";
			cout << "2. Remove employee from the work queue and display his/her info\n";
			cout << "3. Exit Program\n";

			cout << "\nChoice: ";

			cin >> choice;

			switch (choice) {

			case '1':
				cout << "\n\nEnter your first name: ";
				cin >> fname;

				cout << "Enter your last name: ";
				cin >> lname;

				name = fname + " , " + lname;

				cout << "Working hours: ";
				cin >> hoursWorked;

				cout << "Hourly Rate: ";
				cin >> hourlyRate;

				cout << "Income tax rate: ";
				cin >> tax;

				pretax = (hoursWorked * hourlyRate) * tax;

				incomeTax = (hoursWorked * hourlyRate) - pretax;

				insertName(head, tail, name);
				insertNum(head2, tail2, incomeTax);
				break;

			case '2':

				clock_out_name(head);
				dailySalary(head2);

				removeName(head, tail);
				removeNum(head2, tail2);
				break;

			case '3':
				cout << "\nExit";
				delete head, head2, tail, tail2;

				break;

			default: cout << "You didn't select valid menu options.\n ";

			}

		} while (choice != '3');
	}
};

int main() {

	worker que;

	que.selectionMenu();

	return 0;

}